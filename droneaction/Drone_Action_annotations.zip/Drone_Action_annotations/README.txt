You will need to extract the images to folders and give that path in the code for visualization of other actions. natsort and natsortfiles are just for sorting. These annotations were generated using OpenPose. We did not annotate them manually.

bounding boxes and joints annotations are provided.

drawAnnotations_on_image.m file visualizes the annotations on images. 10 sample images are used.

drawAnnotations_on_plain_background. file visualizes the annocations on a black background.