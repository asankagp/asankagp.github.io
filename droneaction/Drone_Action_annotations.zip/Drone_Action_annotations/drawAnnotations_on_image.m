%%% OpenPose readings
% //     {1,  "Nose"},
% //     {2,  "Neck"},
% //     {3,  "RShoulder"},
% //     {4,  "RElbow"},
% //     {5,  "RWrist"},
% //     {6,  "LShoulder"},
% //     {7,  "LElbow"},
% //     {8,  "LWrist"},
% //     {9,  "RHip"},
% //     {10, "RKnee"},
% //     {11, "RAnkle"},
% //     {12, "LHip"},
% //     {13, "LKnee"},
% //     {14, "LAnkle"},
% //     {15, "REye"},
% //     {16, "LEye"},
% //     {17, "REar"},
% //     {18, "LEar"},

clear all, close all

annotpath = 'joint_positions_and_bboxes\clapping\S1_clapping_HD\'; %path to annotations folder
imgpath = 'images\clapping\S1_clapping_HD\'; %path to extracted images folder

annotnames = dir(annotpath);
annotnames={annotnames.name};
annotnames=annotnames(~ismember(annotnames,{'.','..'}));

framenames = dir(imgpath);
framenames={framenames.name};
framenames=framenames(~ismember(framenames,{'.','..'}));
num_framename = length(framenames);

annotnames = natsortfiles(annotnames);
annotname = annotnames{1};
annotname = strcat(annotpath,annotname);
load(annotname);
    
    
for fname = 1: num_framename
    

    xs = pos_img(1,:,fname);
    ys = pos_img(2,:,fname);
    
    framenames = natsortfiles(framenames);
    framename = framenames{fname};
    framename = strcat(imgpath,framename);
    img = imread(framename);
    %     img = rgb2gray(img);
    figure(1),imshow(img),impixelinfo
    
    drawskeleton(xs,ys)
    
    hold on
    rectangle('Position',bbox(:,:,fname),'LineWidth',2,'EdgeColor', 'y')
    hold off
    
end


function drawskeleton(xs,ys)
hold on

tol = 1.e-6; % Should not check floating point numbers for exact equality, so define a tolerance

%draw the skeleton

xs_head = [xs(1),xs(15),xs(16),xs(17),xs(18)];
xs_head = sum(xs_head)/size(nonzeros(xs_head),1);

ys_head = [ys(1),ys(15),ys(16),ys(17),ys(18)];
ys_head = sum(ys_head)/size(nonzeros(ys_head),1);

h=line([xs_head,xs(2)],[ys_head,ys(2)]);
set(h,'color','blue', 'LineWidth',3);

h=line([xs(2),xs(3)],[ys(2),ys(3)]);
set(h,'color','blue', 'LineWidth',3);

if (abs(xs(3))>tol)&&(abs(xs(4))>tol)
    h=line([xs(3),xs(4)],[ys(3),ys(4)]);
    set(h,'color','red', 'LineWidth',3);
end

if (abs(xs(4))>tol)&&(abs(xs(5))>tol)
    h=line([xs(4),xs(5)],[ys(4),ys(5)]);
    set(h,'color','red', 'LineWidth',3);
end

h=line([xs(2),xs(6)],[ys(2),ys(6)]);
set(h,'color','blue', 'LineWidth',3);

if (abs(xs(6))>tol)&&(abs(xs(7))>tol)
    h=line([xs(6),xs(7)],[ys(6),ys(7)]);
    set(h,'color','green', 'LineWidth',3);
end

if (abs(xs(7))>tol)&&(abs(xs(8))>tol)
    h=line([xs(7),xs(8)],[ys(7),ys(8)]);
    set(h,'color','green', 'LineWidth',3);
end
if (abs(xs(9))>tol)&&(abs(xs(12))>tol)
    h=line([xs(9),xs(12)],[ys(9),ys(12)]);
    set(h,'color','blue', 'LineWidth',3);
end
if (abs(xs(9))>tol)&&(abs(xs(3))>tol)
    h=line([xs(9),xs(3)],[ys(9),ys(3)]);
    set(h,'color','blue', 'LineWidth',3);
end
if (abs(xs(6))>tol)&&(abs(xs(12))>tol)
    h=line([xs(6),xs(12)],[ys(6),ys(12)]);
    set(h,'color','blue', 'LineWidth',3);
end
if (abs(xs(9))>tol)&&(abs(xs(10))>tol)
    h=line([xs(9),xs(10)],[ys(9),ys(10)]);
    set(h,'color','magenta', 'LineWidth',3);
end
if (abs(xs(10))>tol)&&(abs(xs(11))>tol)
    h=line([xs(10),xs(11)],[ys(10),ys(11)]);
    set(h,'color','magenta', 'LineWidth',3);
end
if (abs(xs(12))>tol)&&(abs(xs(13))>tol)
    h=line([xs(12),xs(13)],[ys(12),ys(13)]);
    set(h,'color','cyan', 'LineWidth',3);
end
if (abs(xs(13))>tol)&&(abs(xs(14))>tol)
    h=line([xs(13),xs(14)],[ys(13),ys(14)]);
    set(h,'color','cyan', 'LineWidth',3);
end

plot([xs(2:14),xs_head],[ys(2:14),ys_head],'o','MarkerSize',8,'MarkerFaceColor','c')

hold off
end