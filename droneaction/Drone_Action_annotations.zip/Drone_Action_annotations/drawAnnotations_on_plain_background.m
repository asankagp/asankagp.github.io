%%% OpenPose readings
% //     {1,  "Nose"},
% //     {2,  "Neck"},
% //     {3,  "RShoulder"},
% //     {4,  "RElbow"},
% //     {5,  "RWrist"},
% //     {6,  "LShoulder"},
% //     {7,  "LElbow"},
% //     {8,  "LWrist"},
% //     {9,  "RHip"},
% //     {10, "RKnee"},
% //     {11, "RAnkle"},
% //     {12, "LHip"},
% //     {13, "LKnee"},
% //     {14, "LAnkle"},
% //     {15, "REye"},
% //     {16, "LEye"},
% //     {17, "REar"},
% //     {18, "LEar"},

clear all, close all


annotpath = 'joint_positions_and_bboxes\';%joints mat files
% imgpath = '...\';

classnames = dir(annotpath);
classnames={classnames.name};
classnames=classnames(~ismember(classnames,{'.','..'}));
num_classname = length(classnames);



% framenames = dir(imgpath);
% framenames={framenames.name};
% framenames=framenames(~ismember(framenames,{'.','..'}));
% num_framename = length(framenames);



for cname = 1: num_classname
    classname = classnames{cname};
    
    vidnames = dir(strcat(annotpath,classname));
    vidnames = {vidnames.name};
    vidnames = vidnames(~ismember(vidnames,{'.','..'}));
    num_vid = length(vidnames);    
    
    for vname = 1:num_vid
        vidname = vidnames{vname};

        annotnames = dir(strcat(annotpath,classname,'\',vidname));
        annotnames = {annotnames.name};
        annotnames = annotnames(~ismember(annotnames,{'.','..'}));
        num_annot = length(annotnames);
        
        joints=strcat(annotpath,'\',classname,'\',vidname,'\',annotnames);
        joints=string(joints);
        load(joints);
        
        fprintf('showing: %s > %s',classname,vidname)
        for j=1:size(pos_img,3)
            
            
            xs = pos_img(1,:,j);
            ys = pos_img(2,:,j);
            
% %             %create bounding box
% %             Xbb = min(xs(xs>0));
% %             Ybb = min(ys(ys>0));
% %             W = max(xs)-min(xs(xs>0));
% %             H = max(ys)-min(ys(ys>0));
% %             
% %             margin = (max(W,H))*0.05;
% %             
% %             Xbb = Xbb-margin;
% %             Ybb = Ybb-margin;
% %             W = W+(2*margin);
% %             H = H+(2*margin);
% %             bbox(:,:,j) = [Xbb,Ybb,W,H];
            
            
            
%             framenames = natsortfiles(framenames);
%             framename = framenames{j};
%             framename = strcat(imgpath,framename);
%             img = imread(framename);
%             %     img = rgb2gray(img);
%             figure(1),imshow(img),impixelinfo
            
            figure(2), imshow(zeros(1080,1920))
            drawskeleton(xs,ys)
            
            hold on
            rectangle('Position',bbox(:,:,j),'LineWidth',2,'EdgeColor', 'y')
            hold off
        end
        
% %         save(joints, 'pos_img', 'bbox')
        clear bbox pos_img
    end
end
        
        


function drawskeleton(xs,ys)
hold on

tol = 1.e-6; % Should not check floating point numbers for exact equality, so define a tolerance

%draw the skeleton

xs_head = [xs(1),xs(15),xs(16),xs(17),xs(18)];
xs_head = sum(xs_head)/size(nonzeros(xs_head),1);

ys_head = [ys(1),ys(15),ys(16),ys(17),ys(18)];
ys_head = sum(ys_head)/size(nonzeros(ys_head),1);

h=line([xs_head,xs(2)],[ys_head,ys(2)]);
set(h,'color','blue', 'LineWidth',3);

h=line([xs(2),xs(3)],[ys(2),ys(3)]);
set(h,'color','blue', 'LineWidth',3);

if (abs(xs(3))>tol)&&(abs(xs(4))>tol)
    h=line([xs(3),xs(4)],[ys(3),ys(4)]);
    set(h,'color','red', 'LineWidth',3);
end

if (abs(xs(4))>tol)&&(abs(xs(5))>tol)
    h=line([xs(4),xs(5)],[ys(4),ys(5)]);
    set(h,'color','red', 'LineWidth',3);
end

h=line([xs(2),xs(6)],[ys(2),ys(6)]);
set(h,'color','blue', 'LineWidth',3);

if (abs(xs(6))>tol)&&(abs(xs(7))>tol)
    h=line([xs(6),xs(7)],[ys(6),ys(7)]);
    set(h,'color','green', 'LineWidth',3);
end

if (abs(xs(7))>tol)&&(abs(xs(8))>tol)
    h=line([xs(7),xs(8)],[ys(7),ys(8)]);
    set(h,'color','green', 'LineWidth',3);
end
if (abs(xs(9))>tol)&&(abs(xs(12))>tol)
    h=line([xs(9),xs(12)],[ys(9),ys(12)]);
    set(h,'color','blue', 'LineWidth',3);
end
if (abs(xs(9))>tol)&&(abs(xs(3))>tol)
    h=line([xs(9),xs(3)],[ys(9),ys(3)]);
    set(h,'color','blue', 'LineWidth',3);
end
if (abs(xs(6))>tol)&&(abs(xs(12))>tol)
    h=line([xs(6),xs(12)],[ys(6),ys(12)]);
    set(h,'color','blue', 'LineWidth',3);
end
if (abs(xs(9))>tol)&&(abs(xs(10))>tol)
    h=line([xs(9),xs(10)],[ys(9),ys(10)]);
    set(h,'color','magenta', 'LineWidth',3);
end
if (abs(xs(10))>tol)&&(abs(xs(11))>tol)
    h=line([xs(10),xs(11)],[ys(10),ys(11)]);
    set(h,'color','magenta', 'LineWidth',3);
end
if (abs(xs(12))>tol)&&(abs(xs(13))>tol)
    h=line([xs(12),xs(13)],[ys(12),ys(13)]);
    set(h,'color','cyan', 'LineWidth',3);
end
if (abs(xs(13))>tol)&&(abs(xs(14))>tol)
    h=line([xs(13),xs(14)],[ys(13),ys(14)]);
    set(h,'color','cyan', 'LineWidth',3);
end

plot([xs(2:14),xs_head],[ys(2:14),ys_head],'o','MarkerSize',8,'MarkerFaceColor','c')

hold off
end