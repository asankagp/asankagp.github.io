% use this example to create your own occupancy grid
% https://www.mathworks.com/examples/robotics/mw/robotics-ex36926169-grid-coordinates-from-world-coordinate-inputs

clear all, close all

map = robotics.BinaryOccupancyGrid(10,10,5);
xy = [4 4; 4.1 4; 4.2 4; 4.3 4; 4.4 4; 4.5 4; 4.6 4; 4.7 4; 4.8 4; 4.9 4; 5 4; ...
    5.1 4; 5.2 4; 5.3 4; 5.4 4;
    4.1 4.1; 4.2 4.2; 4.3 4.3; 4.4 4.4; 4.5 4.5; 4.6 4.6; 4.7 4.7; 4.8 4.8; 4.9 4.9];
setOccupancy(map,xy,1);

show(map);
hold on
plot(xy(:,1),xy(:,2),'xr','MarkerSize', 20) %red color X represents original points
grid on
set(gca,'XTick',0:0.2:10,'YTick',0:0.2:10)

save ('map1.mat','map')